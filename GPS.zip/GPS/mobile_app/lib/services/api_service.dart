import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  // HARDCODED Host IP as per User Requirement for Physical Device testing
  static const String baseUrl = 'http://192.168.29.7:8000';

  Future<Map<String, dynamic>?> getLastLocation() async {
    final response = await http.get(Uri.parse('$baseUrl/location/'));
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    throw Exception('Failed to load location');
  }

  Future<bool> updateLocation(double lat, double lng) async {
    final response = await http.post(
      Uri.parse('$baseUrl/location/'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'latitude': lat,
        'longitude': lng,
      }),
    );
    return response.statusCode == 200;
  }

  Future<List<dynamic>> getNearbyPlaces(double lat, double lng) async {
    final response = await http.get(
      Uri.parse('$baseUrl/places/nearby?latitude=$lat&longitude=$lng'),
    );
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return data['results'] ?? [];
    } else if (response.statusCode == 503) {
      throw Exception('Service Unavailable');
    }
    throw Exception('Failed to load places');
  }
}
