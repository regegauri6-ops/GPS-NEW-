import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../services/api_service.dart';
import '../services/location_service.dart';
import 'places_list_screen.dart';

class LocationConfirmScreen extends StatefulWidget {
  const LocationConfirmScreen({super.key});

  @override
  State<LocationConfirmScreen> createState() => _LocationConfirmScreenState();
}

class _LocationConfirmScreenState extends State<LocationConfirmScreen> {
  final ApiService _apiService = ApiService();
  final LocationService _locationService = LocationService();

  Position? _currentPosition;
  bool _isLoading = true;
  String _statusMessage = "Fetching location...";

  @override
  void initState() {
    super.initState();
    _fetchAndStoreLocation();
  }

  Future<void> _fetchAndStoreLocation() async {
    setState(() {
      _isLoading = true;
      _statusMessage = "Fetching GPS location...";
    });

    try {
      // 1. Fetch GPS Location
      Position position = await _locationService.getCurrentPosition();

      if (!mounted) return;

      setState(() {
        _statusMessage = "Syncing with server...";
      });

      // 2. Sync with Backend
      // This will throw an exception if network fails (SocketException)
      // or return false if server error (500 etc)
      bool success = await _apiService.updateLocation(
          position.latitude, position.longitude);

      if (!success) {
        throw Exception("Server returned error");
      }

      if (!mounted) return;

      setState(() {
        _currentPosition = position;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);

      // Handle specific errors
      if (e.toString().contains("SocketException") ||
          e.toString().contains("ClientException") ||
          e.toString().contains("Connection refused")) {
        _showNoInternetDialog();
      } else if (e.toString().contains("LocationServiceDisabledException")) {
        _showLocationUnavailableDialog();
      } else {
        // Generic fallback
        _showErrorDialog("Error: $e");
      }
    }
  }

  void _showNoInternetDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text("No Internet Connection"),
        content: const Text("Please check your internet and try again."),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _fetchAndStoreLocation();
            },
            child: const Text("Try Again"),
          ),
        ],
      ),
    );
  }

  void _showLocationUnavailableDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text("Location Unavailable"),
        content: const Text("Please enable GPS and try again."),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _fetchAndStoreLocation();
            },
            child: const Text("Try Again"),
          ),
        ],
      ),
    );
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Error"),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _fetchAndStoreLocation();
            },
            child: const Text("Retry"),
          )
        ],
      ),
    );
  }

  void _onConfirm() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
          builder: (context) => PlacesListScreen(
              latitude: _currentPosition!.latitude,
              longitude: _currentPosition!.longitude)),
    );
  }

  void _onReject() {
    // Requirements say: "fetch current location again, overwrite old one, display updated location"
    _fetchAndStoreLocation();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Confirm Location")),
      body: Center(
        child: _isLoading
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CircularProgressIndicator(),
                  const SizedBox(height: 16),
                  Text(_statusMessage),
                ],
              )
            : Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.location_on, size: 64, color: Colors.blue),
                    const SizedBox(height: 24),
                    Text(
                      "Current Location",
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      "Lat: ${_currentPosition?.latitude.toStringAsFixed(6)}\nLng: ${_currentPosition?.longitude.toStringAsFixed(6)}",
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 18),
                    ),
                    const SizedBox(height: 40),
                    const Text("Is this location correct?",
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton.icon(
                          onPressed: _onReject,
                          icon: const Icon(Icons.refresh),
                          label: const Text("NO (Retry)"),
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red.shade100),
                        ),
                        ElevatedButton.icon(
                          onPressed: _onConfirm,
                          icon: const Icon(Icons.check),
                          label: const Text("YES"),
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green.shade100),
                        ),
                      ],
                    )
                  ],
                ),
              ),
      ),
    );
  }
}
