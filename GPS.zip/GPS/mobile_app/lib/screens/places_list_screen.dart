import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/api_service.dart';

class PlacesListScreen extends StatefulWidget {
  final double latitude;
  final double longitude;

  const PlacesListScreen(
      {super.key, required this.latitude, required this.longitude});

  @override
  State<PlacesListScreen> createState() => _PlacesListScreenState();
}

class _PlacesListScreenState extends State<PlacesListScreen> {
  final ApiService _apiService = ApiService();
  List<dynamic> _places = [];
  bool _isLoading = true;
  String _error = "";
  List<Marker> _markers = [];

  @override
  void initState() {
    super.initState();
    _fetchPlaces();
  }

  Future<void> _fetchPlaces() async {
    setState(() {
      _isLoading = true;
      _error = "";
    });

    try {
      final results =
          await _apiService.getNearbyPlaces(widget.latitude, widget.longitude);

      if (!mounted) return;

      List<Marker> newMarkers = [];
      // User Location Marker or Center
      newMarkers.add(
        Marker(
          point: LatLng(widget.latitude, widget.longitude),
          width: 80,
          height: 80,
          child: const Icon(Icons.my_location, color: Colors.blue, size: 40),
        ),
      );

      for (var place in results) {
        if (place['latitude'] != null && place['longitude'] != null) {
          newMarkers.add(
            Marker(
              point: LatLng(place['latitude'], place['longitude']),
              width: 80,
              height: 80,
              child: const Icon(Icons.location_on, color: Colors.red, size: 40),
            ),
          );
        }
      }

      setState(() {
        _places = results;
        _markers = newMarkers;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);

      // Handle specific errors
      if (e.toString().contains("SocketException") ||
          e.toString().contains("ClientException") ||
          e.toString().contains("Connection refused")) {
        _showNoInternetDialog();
      } else {
        setState(() {
          _error = e.toString();
        });
      }
    }
  }

  void _showNoInternetDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text("No Internet Connection"),
        content: const Text("Please check your internet and try again."),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _fetchPlaces();
            },
            child: const Text("Try Again"),
          ),
        ],
      ),
    );
  }

  Future<void> _launchMap(String url) async {
    if (!await launchUrl(Uri.parse(url),
        mode: LaunchMode.externalApplication)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Could not open map")),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Nearby Places")),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error.isNotEmpty
              ? Center(child: Text("Error: $_error"))
              : Column(
                  children: [
                    // Map Section
                    SizedBox(
                      height: 300,
                      child: FlutterMap(
                        options: MapOptions(
                          initialCenter:
                              LatLng(widget.latitude, widget.longitude),
                          initialZoom: 14.0,
                        ),
                        children: [
                          TileLayer(
                            urlTemplate:
                                'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                            userAgentPackageName: 'com.example.mobile_app',
                          ),
                          MarkerLayer(markers: _markers),
                        ],
                      ),
                    ),
                    // List Section
                    Expanded(
                      child: ListView.builder(
                        itemCount: _places.length,
                        itemBuilder: (context, index) {
                          final place = _places[index];
                          return Card(
                            margin: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            child: ListTile(
                              leading: const Icon(Icons.local_hospital,
                                  color: Colors.red),
                              title: Text(place['name'] ?? "Unknown",
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold)),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(place['address'] ?? ""),
                                  const SizedBox(height: 4),
                                  Text(place['phone_number'] ?? "No Phone"),
                                ],
                              ),
                              trailing: IconButton(
                                icon: const Icon(Icons.map, color: Colors.blue),
                                onPressed: () {
                                  if (place['maps_link'] != null) {
                                    _launchMap(place['maps_link']);
                                  }
                                },
                              ),
                              isThreeLine: true,
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
    );
  }
}
