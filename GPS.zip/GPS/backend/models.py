from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean
from sqlalchemy.sql import func
from database import Base

class UserLocation(Base):
    __tablename__ = "user_locations"

    id = Column(Integer, primary_key=True, index=True)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    # Keeping it simple: One current location per user (or just one global row for single-user dev)
    # In a real app, you'd have user_id. Here we will just update the latest entry or create new.
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # For PostGIS later:
    # location = Column(Geometry("POINT")) 
    # Use GeoAlchemy2 for full PostGIS support.

class CachedPlace(Base):
    __tablename__ = "cached_places"

    id = Column(Integer, primary_key=True, index=True)
    osm_id = Column(String, unique=True, index=True)
    name = Column(String)
    type = Column(String)
    latitude = Column(Float, nullable=False, index=True)
    longitude = Column(Float, nullable=False, index=True)
    address = Column(String, nullable=True)
    phone = Column(String, nullable=True)
    cached_at = Column(DateTime(timezone=True), server_default=func.now())
