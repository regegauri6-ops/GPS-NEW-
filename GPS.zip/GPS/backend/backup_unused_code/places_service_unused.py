import os

# Environment Variables
USE_MOCK_PLACES = os.getenv("USE_MOCK_PLACES", "true").lower() == "true"
GOOGLE_PLACES_API_KEY = os.getenv("GOOGLE_PLACES_API_KEY", "")

# Mock Data
MOCK_PLACES = [
    {
        "name": "City General Hospital",
        "phone_number": "+1-555-0123",
        "address": "123 Main St, Springfield",
        "maps_link": "https://www.google.com/maps/search/?api=1&query=City+General+Hospital",
        "type": "hospital"
    },
    {
        "name": "Dr. Smith's Dental Clinic",
        "phone_number": "+1-555-0199",
        "address": "45 Elm St, Springfield",
        "maps_link": "https://www.google.com/maps/search/?api=1&query=Dr+Smith+Dental",
        "type": "clinic"
    },
    {
        "name": "Downtown Medical Center",
        "phone_number": "+1-555-2233",
        "address": "789 Pine Ave, Springfield",
        "maps_link": "https://www.google.com/maps/search/?api=1&query=Downtown+Medical+Center",
        "type": "hospital"
    },
     {
        "name": "Springfield Family Doctor",
        "phone_number": "+1-555-4455",
        "address": "321 Oak St, Springfield",
        "maps_link": "https://www.google.com/maps/search/?api=1&query=Springfield+Family+Doctor",
        "type": "doctor"
    }
]
