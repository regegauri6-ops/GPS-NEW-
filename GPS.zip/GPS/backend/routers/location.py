from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
import schemas, crud, database

router = APIRouter(
    prefix="/location",
    tags=["location"]
)

@router.post("/", response_model=schemas.LocationResponse)
def update_location(location: schemas.LocationCreate, db: Session = Depends(database.get_db)):
    """
    Receive and store user location.
    If a record exists, it updates it (single user model).
    """
    return crud.create_or_update_location(db=db, location=location)

@router.get("/", response_model=schemas.LocationResponse)
def read_location(db: Session = Depends(database.get_db)):
    """
    Get the last stored location.
    """
    db_location = crud.get_latest_location(db)
    if db_location is None:
        raise HTTPException(status_code=404, detail="Location not found")
    return db_location
