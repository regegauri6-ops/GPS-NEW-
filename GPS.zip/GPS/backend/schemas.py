from pydantic import BaseModel
from datetime import datetime
from typing import Optional, List

class LocationBase(BaseModel):
    latitude: float
    longitude: float

class LocationCreate(LocationBase):
    pass

class LocationResponse(LocationBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

class Place(BaseModel):
    name: str
    phone_number: Optional[str] = None
    address: Optional[str] = None
    maps_link: str
    type: str  # Doctor, Clinic, Hospital
    latitude: Optional[float] = None
    longitude: Optional[float] = None

class PlacesResponse(BaseModel):
    results: List[Place]
